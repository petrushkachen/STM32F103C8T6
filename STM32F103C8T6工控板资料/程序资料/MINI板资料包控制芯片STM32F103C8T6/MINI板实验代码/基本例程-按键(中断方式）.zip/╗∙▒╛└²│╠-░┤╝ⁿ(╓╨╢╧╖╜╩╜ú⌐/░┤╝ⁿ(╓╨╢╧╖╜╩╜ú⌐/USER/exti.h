#ifndef __EXTI_H
#define	__EXTI_H

#include "stm32f10x.h"
void EXTI_PB12_Config(void);

#endif /* __XXX_H */
